# نور الإيمان - طريقة الحصول على APK

1. صاوب repository جديد فـ GitHub وحط فيه كل ملفات هاد المجلد (بما فيهم مجلد `.github`).
   - إلا ما ظهرش ليك `.github` فالهاتف: فـ GitHub دير Add file > Create new file، سمي الملف
     `.github/workflows/build-apk.yml` وانسخ فيه محتوى `workflow-copy/build-apk.yml`.
2. مور ما تدير commit، سير لتبويب Actions، غادي يبدا "Build Android APK" بوحدو (ولا دير Run workflow).
3. ملي يوفي (تقريبا 5 إلى 8 دقايق) حل التشغيل لي نجح، ونزل `nour-al-iman-apk` من Artifacts، فك الضغط وثبت `app-debug.apk`.
4. فاش تحل التطبيق أول مرة، قبل الإشعارات. من تبويب إدارة ضغط "تفعيل التنبيهات".

التنبيهات: 06:00 أذكار الصباح، 18:00 أذكار المساء، 23:00 أذكار النوم.
